/*
 * write a program to do sorting of multiple arrays using multithreading.


int[] array1={23,34,78,90};
int[] array2={89,23};
int[] array3={12,34,67};

After arrays are sorted print sorted arrays.
 */

package Assignment_06_nov;

import java.util.Arrays;

public class Array implements Runnable{
	
	int[] arr1={79,23,34,78,90};
	int[] arr2={55,3,20,89,23};
	int[] arr3={80,43,12,34,67};
	
	@Override
	public void run() {
		try {
			Arrays.sort(arr1);
			Arrays.sort(arr2);
			Arrays.sort(arr3);
			
			for(int i=0;i<arr1.length;i++) {
				System.out.println("Sorted array1 - "+arr1[i]);
				Thread.sleep(1000);
			}
			for(int i=0;i<arr2.length;i++) {
				System.out.println("Sorted array2 - "+arr2[i]);
				Thread.sleep(1000);
			}
			for(int i=0;i<arr3.length;i++) {
				System.out.println("Sorted array3 - "+arr3[i]);
				Thread.sleep(1000);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args) {
		Thread thread = new Thread(new Array());
		thread.start();
	}
	
}