/*
 * 
 101 sabbir 45 54 67 81 71 66
 102 amit 95 66 62 88 79 63
....

Read data from student.dat and compute percentage of each student
 */

package StudentData;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import javax.imageio.stream.FileCacheImageInputStream;

public class SerilizableDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Scanner sc=new Scanner(System.in);
       // Serilizable
		
		FileOutputStream fos=new FileOutputStream("Test.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
		Student s=new Student(101, "sabbir", 45, 54, 67, 81, 90, 66);
		Student s1=new Student(102, "amit", 45,64, 67, 74, 71, 66);
		//oos.writeObject(s);
		oos.writeObject(s1);
		
		
	// Deserilizable	
		
		FileInputStream fis=new FileInputStream("Test.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		Student s2=(Student) ois.readObject();
		System.out.println(s2);
		
		
		oos.close();
		fos.close();


	}

	

}
