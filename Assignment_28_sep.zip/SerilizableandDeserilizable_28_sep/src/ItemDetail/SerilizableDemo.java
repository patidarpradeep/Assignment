package ItemDetail;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerilizableDemo {
	
	public static void main(String args[]) throws IOException, ClassNotFoundException
	{
		
      FileOutputStream fos=new FileOutputStream("Item.txt");
      ObjectOutputStream oos=new ObjectOutputStream(fos);
      
      Item i=new Item(1,"IPhone",6,34876.58,5);
      oos.writeObject(i);
      
      FileInputStream fis=new FileInputStream("Item.txt");
      ObjectInputStream ois=new ObjectInputStream(fis);
     Item i1=(Item) ois.readObject();
     System.out.println(i1);
      
     // fos.close();
     // oos.close();
      fis.close();
      ois.close();
      
	}

}
