/*
 *  Ask user to enter file path.Ask user to search for a word in a file.

    Ask user to enter word to be replaced with

    Search for that word in file and replace it with new word entered by user.

     path:d:\\IO\\File1.txt
     Search: Java
     Replace: Python
 */

package Fileoperation_27sep;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.Buffer;
import java.util.Scanner;

public class Replaceword {
	
	public static void main(String args[]) throws IOException, ClassNotFoundException {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the file path;");
		
       	String path=s.nextLine();
		// D:\TraningJava\Test.txt
	
		File f=new File(path);
		
		BufferedReader bf=new BufferedReader(new FileReader(f));
		String str1=bf.readLine();
		System.out.println("Befor the Replace String are:");
		System.out.println(str1);
		
		System.out.println();
		System.out.println("After the Replace Java BY Pythone");
		
		String str2=str1.replaceAll("java", "Python");
		System.out.println(str2);
	}

}
