/* 1. put student data into a file student.dat


 101 sabbir 45 54 67 81 71 66
 102 amit 95 66 62 88 79 63
....

Read data from student.dat and compute percentage of each student and sort student data based on percentage.
*/

package StudentData;

import java.io.Serializable;

public class Student implements Serializable{
	private int student_rollno;
	private String student_name;
	private int marks1;
	private int marks2;
	private int marks3;
	private int marks4;
	private int marks5;
	private int marks6;
	private int add;
	private int percentage;
	
	public Student() {
		
	}

	public Student(int student_rollno, String student_name, int marks1, int marks2, int marks3, int marks4, int marks5,
			int marks6) {
		super();
		this.student_rollno = student_rollno;
		this.student_name = student_name;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
		this.marks4 = marks4;
		this.marks5 = marks5;
		this.marks6 = marks6;
	}

	
	public int getStudent_rollno() {
		return student_rollno;
	}

	public String getStudent_name() {
		return student_name;
	}

	public int getMarks1() {
		return marks1;
	}

	public int getMarks2() {
		return marks2;
	}

	public int getMarks3() {
		return marks3;
	}

	public int getMarks4() {
		return marks4;
	}

	public int getMarks5() {
		return marks5;
	}

	public int getMarks6() {
		return marks6;
	}

	@Override
	public String toString() {
		return "Student [student_rollno=" + student_rollno + ", student_name=" + student_name + ", marks1=" + marks1
				+ ", marks2=" + marks2 + ", marks3=" + marks3 + ", marks4=" + marks4 + ", marks5=" + marks5
				+ ", marks6=" + marks6 +  ", Percentage ="  + percent()+"]";
		    
	}

	private int percent() {
		int add=0;
		int percent;
		add=marks1+marks2+ marks2+marks4+marks5;
		percent=(add*100)/600;
		return  percent;
	}
	
	

}
