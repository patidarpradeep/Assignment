/*
 * Ask end user to enter date of birth.

   Identify day birthday will fall in next year.
 */
package DateTimeApi_14oct;

import java.time.LocalDate;
import java.util.Scanner;

public class DOB {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
    System.out.println("Enter the  date of month :");
    int day=sc.nextInt();
    System.out.println("Enter the month :");
    int month=sc.nextInt();
    System.out.println("Enter the year:");
    int year=sc.nextInt();
    
    System.out.println("present year day:");
    LocalDate d=LocalDate.of(year, month, day);
    System.out.println(d);
    System.out.println(d.getDayOfWeek());
    
    System.out.println();
    LocalDate d1=d.plusYears(1);
    System.out.println("next year day:");
    System.out.println(d1);
    System.out.println(d1.getDayOfWeek());
	}

}
