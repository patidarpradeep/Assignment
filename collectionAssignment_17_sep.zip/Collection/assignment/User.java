
/* 1. Ask user to enter five names

   convert third character in a name to uppercase  */


package Collection.assignment;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class User {

	public static void main(String[] args) {
		
		ArrayList<String> list= new ArrayList<>();
		ArrayList<String> list2= new ArrayList<>();
		Scanner sc=new Scanner(System.in);
        
      
    for(int i=0;i<5;i++)
    {
    	list.add(sc.nextLine());
    }
    
    
    for(int i=0;i<5;i++)
    {
    	String str=list.get(i);
    	 for(int j=0;j<str.length();j++)
    	 {
    		 Character c=str.charAt(j);
    		if(j == 2)
    		{
    			String g= str.replace(c, Character.toUpperCase(c));
    		      list2.add(g);
    		}
    		} 	 
    }
    for(int i=0;i<5;i++)
    {
    	System.out.println(list2.get(i));
    }
	}

	
	}

