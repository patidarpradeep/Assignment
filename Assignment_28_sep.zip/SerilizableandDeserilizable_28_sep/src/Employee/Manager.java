package Employee;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Manager extends EmpDetail{
 //EmpDetail e=new EmpDetail();
	  public int  managerId;

	public Manager(int empId, String empFirstName, String empLastName, String empDOB, String empGender, int managerId) {
		super(empId, empFirstName, empLastName, empDOB, empGender);
		this.managerId = managerId;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId+ "empId=" + EmpDetail.getEmpId() + ", empFirstName=" + EmpDetail.getEmpFirstName() + ", empLastName=" + EmpDetail.getEmpLastName()
				 + ", empGender=" +EmpDetail.getEmpGender() +"]";
	}
	
	
		}

	  
	

