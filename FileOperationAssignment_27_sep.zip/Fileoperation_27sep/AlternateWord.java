/*
 * Ask user to enter file path. Convert all words at alternative position into uppercase excluding spaces.
    Java is a programming language.
    java IS a PROGRAMMING language.
 */

package Fileoperation_27sep;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class AlternateWord {

	public static void main(String[] args) throws IOException {
		
		FileReader fr=new FileReader("D:\\TraningJava\\Test.txt");
        BufferedReader bf=new BufferedReader(fr);
        String str=bf.readLine();
        String[] str1=str.split(" ");
        try {
        for(int i=0;i<str1.length;i=i+2)
        {
        	for(int j=i;j<str1.length;j++)
        	{
        	if(str1[i]==str1[j]) {
             System.out.print(str1[j].toUpperCase()+" ");
             //System.out.print(str2+" ");
        	}
        	}
        	
         System.out.print(str1[i+1]+" ");
        
  
        }
        }catch(Exception e) {
        	System.out.println();
        }
	}

}
