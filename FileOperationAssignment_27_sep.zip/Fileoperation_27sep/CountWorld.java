/*
 * 2. Ask user to enter file path. Count number of words in that file, 
 * count number of numbers in that file.
 */

package Fileoperation_27sep;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;
import java.util.Scanner;

public class CountWorld {

	public static void main(String[] args) throws IOException {
		
		
		String word;
		 int countword=0,countnumber=0;
		 
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the file path;");
		
		String path=s.nextLine();
		// D:\TraningJava\Test.txt
		FileInputStream fr=new FileInputStream(path);
		//BufferedReader br=new BufferedReader(fr);
		
		Scanner sc= new Scanner(fr);
	
		
		String numRegex = ".*[0-9].*";
		String alpharegex =".*[A-Za-z].*";
		
		while(sc.hasNext())
		{
		     word=sc.next();
		    if(word.matches(alpharegex))
		    {
		    	countword++;
		    }
		    else if(word.matches(numRegex))
		    {
		    	countnumber++;
		    }
			
		}
		sc.close();
		System.out.println("Total word in file:"+ countword);
		System.out.println("Total number in file:"+ countnumber);
		
	}

}
