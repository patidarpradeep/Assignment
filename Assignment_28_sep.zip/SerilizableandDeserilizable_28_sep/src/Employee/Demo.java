package Employee;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Demo {
	
	public static void main(String args[]) throws IOException, ClassNotFoundException {
		
		
		FileOutputStream fos=new FileOutputStream("Employee.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
		Manager m=new Manager( 1, "pradeep", "patidar", "27/05/1999", "male",10);
		oos.writeObject(m);
		
		FileInputStream fis=new FileInputStream("Employee.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		Manager m1=(Manager) ois.readObject();
		System.out.println(m1);
		
		fos.close();
		oos.close();
		fis.close();
		ois.close();
	}

}
