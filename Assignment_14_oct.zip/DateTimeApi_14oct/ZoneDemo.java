/*
 *  Get current time for following cities,

   1.London
   2.Berlin
   3.New York
   4.Mumbai
   5.Singapore
 */

package DateTimeApi_14oct;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Set;

public class ZoneDemo {

	public static void main(String[] args) {

		
		
		ZoneId europeParis=ZoneId.of("Europe/London");
		ZoneId europeBerlin=ZoneId.of("Europe/Berlin");
		ZoneId IndianMumbai=ZoneId.of("Asia/Calcutta");
		ZoneId europeNewYork=ZoneId.of("America/New_York");
		ZoneId europeSingapore=ZoneId.of("Asia/Singapore");
		LocalDateTime localDateTime=LocalDateTime.now();
		
		ZonedDateTime zonedDateTime=ZonedDateTime.of(localDateTime, europeParis);
		ZonedDateTime zonedDateTime1=ZonedDateTime.of(localDateTime,europeBerlin);
		ZonedDateTime zonedDateTime2=ZonedDateTime.of(localDateTime, IndianMumbai);
		ZonedDateTime zonedDateTime3=ZonedDateTime.of(localDateTime, europeNewYork);
		ZonedDateTime zonedDateTime4=ZonedDateTime.of(localDateTime, europeSingapore);
		
		
		System.out.println(zonedDateTime);
		System.out.println(zonedDateTime1);
		System.out.println(zonedDateTime2);
		System.out.println(zonedDateTime3);
		System.out.println(zonedDateTime4);
		
	}

}

