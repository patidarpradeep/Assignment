/*
 *  Ask user to enter 6 student records with following attributes

   Roll No
   firstName
   lastName
   age
   semester 1 marks
   semester 2 marks
   semester 3 marks

 display Sorted student details based on age,firstName and lastName in ascending order.

 display Sorted student details based on percentage of semester marks in descending order.

 */

package Collection.assignment;

import java.util.Comparator;

public class StudentDetail {
	  private int  roll_no;
	  private  String firstName;
	  private String   lastName;
	  private int age;
	  private int semester_1_marks;
	  private int semester_2_marks;
	  private int semester_3_marks;
	
	public StudentDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDetail(int roll_no, String firstName, String lastName, int age, int semester_1_marks,
			int semester_2_marks, int semester_3_marks) {
		super();
		this.roll_no = roll_no;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.semester_1_marks = semester_1_marks;
		this.semester_2_marks = semester_2_marks;
		this.semester_3_marks = semester_3_marks;
		
		
	}
	public int getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSemester_1_marks() {
		return semester_1_marks;
	}
	public void setSemester_1_marks(int semester_1_marks) {
		this.semester_1_marks = semester_1_marks;
	}
	public int getSemester_2_marks() {
		return semester_2_marks;
	}
	public void setSemester_2_marks(int semester_2_marks) {
		this.semester_2_marks = semester_2_marks;
	}
	public int getSemester_3_marks() {
		return semester_3_marks;
	}
	public void setSemester_3_marks(int semester_3_marks) {
		this.semester_3_marks = semester_3_marks;
	}
	
	  public static Comparator<StudentDetail> StuFirstNameComparator = new Comparator<StudentDetail>() {

			public int compare(StudentDetail s1, StudentDetail s2) {
			   String StudentName1 = s1.getFirstName().toUpperCase();
			   String StudentName2 = s2.getFirstName().toUpperCase();

			  
			   return StudentName1.compareTo(StudentName2);

			   
		    }};

		   public static Comparator<StudentDetail> stuLastNameComparator=new Comparator<StudentDetail>() {
			   
			   public int compare(StudentDetail s1,StudentDetail s2) {
				  
				   String StudentName1=s1.getLastName().toUpperCase();
				   String StudentName2=s2.getLastName().toUpperCase();
				   
				   return StudentName1.compareTo(StudentName2);
				   
			   }};
			   
		  public static Comparator<StudentDetail>   stdAgeComparator=new Comparator<StudentDetail>() {
			  
			  public int compare(StudentDetail s1,StudentDetail s2) {
				  int StudentName1=s1.getAge();
				  int StudentName2=s2.getAge();
				  
				  return   StudentName1-StudentName2;
				  
				  
				  
			  }};
			  
			
			  
			  public static Comparator<StudentDetail>   stdPercentComparator=new Comparator<StudentDetail>() {
				  
				  public  int compare(StudentDetail s1,StudentDetail s2) {
					  int StudentName1=s1.percent(s1.getSemester_1_marks(),s1.getSemester_2_marks(),s1.getSemester_3_marks());
					  int  StudentName2=s2.percent(s2.getSemester_1_marks(),s2.getSemester_2_marks(),s2.getSemester_3_marks());
					   
					  return   StudentName1-StudentName2;
					  
					  
					  
				  }};
		    
	@Override
	public String toString() {
	
		return "StudentDetail [roll_no=  " + roll_no + ", firstName=  " + firstName + ", lastName= " + lastName + ", age=  "
				+ age + ", semester_1_marks=  " + semester_1_marks + ", semester_2_marks=  " + semester_2_marks
				+ ", semester_3_marks=  " + semester_3_marks + ", percentage =  " + percent(semester_1_marks,semester_2_marks,semester_3_marks)+  "]";
	}
	
	
	
	
	 private static int  percent(int s1,int s2,int s3) {
	       int add=0;
	       int per;
	       add=add+(s1+s2+s3);
	       per=(add*100)/300; 
		   return per;
	
	
	 }  

}
