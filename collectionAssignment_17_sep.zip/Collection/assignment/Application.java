package Collection.assignment;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class Application {
	static ArrayList<StudentDetail> l1=new ArrayList<>(6);
	
	static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String args[])
	{
		  
		 l1.add(new StudentDetail(4,"ram","shrma",19,56,76,34));
		 l1.add(new StudentDetail(1,"pradeep","patidar",23,45,67,84));
		 l1.add(new StudentDetail(2,"sunil","kholi",34,45,76,38));
		 l1.add(new StudentDetail(3,"H","verma",14,67,89,69));
		
		 System.out.println("Student Detail Without Soarting");
	     for(StudentDetail sd: l1)
	     {
	    	 System.out.println(sd);
	     }
	
	     System.out.println();
	    System.out.println("Sorting based of First name");
	    Collections.sort(l1, StudentDetail.StuFirstNameComparator);
	    for(StudentDetail str: l1)
	    {
	    	System.out.println(str);
	    }
	    
	    System.out.println();
	    System.out.println("Sorting based of Last name");
	    Collections.sort(l1 , StudentDetail.stuLastNameComparator);
	    for(StudentDetail str1 : l1)
	    {
	    	System.out.println(str1);
	    }
	    
	    
	    	     
	    System.out.println();
	    System.out.println("Sorting based on Age");
	    Collections.sort(l1, StudentDetail.stdAgeComparator);
	    for(StudentDetail s: l1) {
	    	System.out.println(s);
	    }
	    
	    System.out.println();
	    System.out.println("Sorting based on percentage");
	    Collections.sort(l1, StudentDetail.stdPercentComparator);
	    for(StudentDetail s: l1) {
	    	System.out.println(s);
	    }
	    	
	  
	    
	}

	  
	}


