//Identify number of Years from 15th August,1947 till now
package DateTimeApi_14oct;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.Year;

public class NumberOfYears {

	public static void main(String[] args) {
	
	 
	 LocalDate start = LocalDate.of(1947, Month.AUGUST,15);
	 LocalDate end = LocalDate.now();
	 
	 Period p=Period.between(start, end);
	 int year=p.getYears();
	 
     System.out.println(year);
	 
	}
}
