/*
 *  Create a class Employee with following attributes

    empId
    empFirstName
    empLastName
    empDOB
    empGender

  create subclass Manager of Employee with following attributes

   managerId

  Serialize object of manager except empDOB and deserialize and print details on console.
 */

package Employee;

import java.io.Serializable;

import javax.xml.crypto.Data;

public class EmpDetail implements Serializable {
	
	public  static  int empId;
	public  static  String  empFirstName;
	public static  String  empLastName;
	public static  String   empDOB;
	public static String empGender;
	
	
	
	public EmpDetail() {
		super();
		// TODO Auto-generated constructor stub
	}



	public EmpDetail(int empId, String empFirstName, String empLastName, String empDOB, String empGender) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDOB = empDOB;
		this.empGender = empGender;
	}



	public static int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public static String getEmpFirstName() {
		return empFirstName;
	}



	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}



	public static  String getEmpLastName() {
		return empLastName;
	}



	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}



	public static String getEmpDOB() {
		return empDOB;
	}



	public void setEmpDOB(String i) {
		this.empDOB = i;
	}



	public static String getEmpGender() {
		return empGender;
	}



	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}



	/*public String toString() {
		return "EmpDetail [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDOB=" + empDOB + ", empGender=" + empGender + "]";
	}
	*/
	
	

}
